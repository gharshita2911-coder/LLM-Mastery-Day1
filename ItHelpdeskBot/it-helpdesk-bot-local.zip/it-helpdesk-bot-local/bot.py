"""
bot.py  (LOCAL / EMULATOR VERSION)
------------------------------------
Core conversation logic for the IT Helpdesk Bot.

Conversation lifecycle:
  1. User sends a message (or types 'menu').
  2. Bot tries to match a category via keyword; if no match, shows the menu.
  3. User selects a category (by number or keyword).
  4. Bot presents troubleshooting steps one at a time.
  5. After each step the user replies Yes / No / Skip.
     - Yes  → resolved, reset state.
     - No / Skip → next step; if all exhausted, ask for asset ID.
  6. User provides asset ID → escalation email is sent.

State is stored in MemoryStorage (local dev only).
For production swap to CosmosDbPartitionedStorage or BlobStorage.
"""

import logging
from botbuilder.core import (
    ActivityHandler,
    ConversationState,
    MemoryStorage,
    TurnContext,
)
from botbuilder.schema import ChannelAccount

from knowledge_base import (
    CATEGORIES,
    get_category_by_keyword,
    get_category_by_number,
    get_menu_text,
)
from escalation import send_escalation_email

logger = logging.getLogger(__name__)

# ── In-memory storage ─────────────────────────────────────────────────────────
_storage        = MemoryStorage()
conversation_state = ConversationState(_storage)


# ── Conversation state schema ─────────────────────────────────────────────────
# We use a plain dict stored under one property key rather than a dataclass
# because MemoryStorage serialises/deserialises via JSON and plain dicts
# survive that round-trip without any extra configuration.

def _blank_state() -> dict:
    return {
        "category_key":     "",    # active helpdesk category
        "step_index":       0,     # index of current troubleshooting step
        "steps_tried":      [],    # steps already shown to the user
        "awaiting_asset_id": False,# True after all steps are exhausted
        "asset_id":         "",    # provided by user before escalation
    }


# ── Bot class ─────────────────────────────────────────────────────────────────

class ITHelpdeskBot(ActivityHandler):
    """Main bot — handles all incoming activities from the emulator / Teams."""

    def __init__(self):
        self._state_prop = conversation_state.create_property("conv")

    # ── Built-in activity handlers ────────────────────────────────────────────

    async def on_members_added_activity(
        self, members_added: list[ChannelAccount], turn_context: TurnContext
    ):
        """
        Fired when a new member joins the conversation.
        In the emulator this fires when you first connect.
        """
        for member in members_added:
            # Don't greet the bot itself
            if member.id != turn_context.activity.recipient.id:
                logger.info("New member joined: %s", member.name or member.id)
                await turn_context.send_activity(
                    "👋 Hi! I'm the **IT Helpdesk Bot**.\n\n"
                    "I can help you troubleshoot common IT issues step by step.\n\n"
                    + get_menu_text()
                )

    async def on_message_activity(self, turn_context: TurnContext):
        """Handle every text message sent by the user."""

        user_text = (turn_context.activity.text or "").strip()
        is_group   = bool(getattr(turn_context.activity.conversation, "is_group", False))
        is_private = not is_group

        logger.info(
            "MESSAGE | user=%s | text=%r | is_group=%s",
            turn_context.activity.from_property.name,
            user_text,
            is_group,
        )

        # Load (or initialise) state for this conversation
        state: dict = await self._state_prop.get(turn_context, _blank_state)

        # ── Global reset commands ──────────────────────────────────────────────
        if user_text.lower() in ("menu", "help", "start", "hi", "hello", "restart"):
            _reset(state)
            await turn_context.send_activity(get_menu_text())

        # ── Waiting for asset ID ───────────────────────────────────────────────
        elif state["awaiting_asset_id"]:
            await self._handle_asset_id(state, turn_context, user_text)

        # ── Active category — Yes / No / Skip ─────────────────────────────────
        elif state["category_key"]:
            await self._handle_step_response(state, turn_context, user_text)

        # ── No active category — try to identify one ───────────────────────────
        else:
            cat_key = (
                get_category_by_number(user_text)
                or get_category_by_keyword(user_text)
            )
            if cat_key:
                await self._start_category(state, turn_context, cat_key, is_private)
            else:
                await turn_context.send_activity(
                    "I didn't quite understand that.\n\n"
                    "Please choose a category by number or describe your issue.\n\n"
                    + get_menu_text()
                )

        # Persist state changes
        await conversation_state.save_changes(turn_context, False)

    # ── Flow helpers ──────────────────────────────────────────────────────────

    async def _start_category(
        self,
        state: dict,
        turn_context: TurnContext,
        cat_key: str,
        is_private: bool,
    ):
        """Initialise state for the chosen category and send the first step."""
        data = CATEGORIES[cat_key]

        # Connectivity category contains WiFi passwords — private chat only
        if data.get("private_only") and not is_private:
            await turn_context.send_activity(
                f"🔒 **{data['display_name']}** may involve sensitive information "
                "(e.g. WiFi passwords).\n\n"
                "Please **open a private chat** with me to continue safely."
            )
            return

        state["category_key"]      = cat_key
        state["step_index"]        = 0
        state["steps_tried"]       = []
        state["awaiting_asset_id"] = False
        state["asset_id"]          = ""

        steps = data["steps"]
        logger.info("Starting category=%s  total_steps=%d", cat_key, len(steps))

        await turn_context.send_activity(
            f"🔍 **{data['display_name']}** — let's troubleshoot together.\n\n"
            f"I have {len(steps)} steps to try. After each one reply:\n"
            "**Yes** — that fixed it  |  **No** — didn't help  |  **Skip** — skip this step\n\n"
            "Type **menu** at any time to start over.\n"
            "─────────────────────────────────────"
        )
        await self._show_step(state, turn_context)

    async def _show_step(self, state: dict, turn_context: TurnContext):
        """Send the current troubleshooting step to the user."""
        data  = CATEGORIES[state["category_key"]]
        steps = data["steps"]
        idx   = state["step_index"]
        step  = steps[idx]

        if step not in state["steps_tried"]:
            state["steps_tried"].append(step)

        logger.info("Showing step %d/%d for %s", idx + 1, len(steps), state["category_key"])

        await turn_context.send_activity(
            f"**Step {idx + 1} of {len(steps)}:**\n\n"
            f"{step}\n\n"
            "─────────────────────────────────────\n"
            "Did this resolve the issue?  Reply **Yes**, **No**, or **Skip**."
        )

    async def _handle_step_response(
        self, state: dict, turn_context: TurnContext, user_text: str
    ):
        """Process Yes / No / Skip reply."""
        lower = user_text.lower()

        if lower in ("yes", "y", "resolved", "fixed", "works", "worked", "done"):
            await turn_context.send_activity(
                "✅ Great — glad that resolved the issue!\n\n"
                "Type **menu** if you need help with something else."
            )
            _reset(state)

        elif lower in ("no", "n", "nope", "skip", "s", "next"):
            steps = CATEGORIES[state["category_key"]]["steps"]
            state["step_index"] += 1

            if state["step_index"] < len(steps):
                await self._show_step(state, turn_context)
            else:
                state["awaiting_asset_id"] = True
                await turn_context.send_activity(
                    "😕 We've tried all the available steps without resolving the issue.\n\n"
                    "Please share your **laptop or asset ID** "
                    "(the sticker on the bottom of your device, e.g. `ASSET-12345`) "
                    "so I can raise a ticket with the IT team."
                )
        else:
            await turn_context.send_activity(
                "Please reply with **Yes**, **No**, or **Skip** to continue."
            )

    async def _handle_asset_id(
        self, state: dict, turn_context: TurnContext, asset_id: str
    ):
        """Collect asset ID and send escalation email."""
        if not asset_id or len(asset_id.strip()) < 2:
            await turn_context.send_activity(
                "Please provide a valid asset ID (e.g. `ASSET-12345`)."
            )
            return

        state["asset_id"] = asset_id.strip()
        data = CATEGORIES[state["category_key"]]

        from_prop  = turn_context.activity.from_property
        user_name  = getattr(from_prop, "name", None) or "Unknown User"
        user_email = getattr(from_prop, "email", None) \
                     or f"{user_name.lower().replace(' ', '.')}@company.com"

        logger.info(
            "Escalating: user=%s  category=%s  asset=%s  urgent=%s",
            user_name, state["category_key"], state["asset_id"], data.get("urgent", False)
        )

        await turn_context.send_activity("📧 Raising escalation — one moment...")

        success = await send_escalation_email(
            user_name        = user_name,
            user_email       = user_email,
            category_display = data["display_name"],
            steps_tried      = state["steps_tried"],
            asset_id         = state["asset_id"],
            urgent           = data.get("urgent", False),
        )

        if success:
            urgent_note = (
                "\n\n🔴 **Flagged as URGENT** — the IT Security team will contact you shortly."
                if data.get("urgent") else ""
            )
            await turn_context.send_activity(
                f"✅ **Escalation raised.**{urgent_note}\n\n"
                f"**Ticket summary:**\n"
                f"- Category : {data['display_name']}\n"
                f"- Asset ID  : `{state['asset_id']}`\n"
                f"- Steps tried: {len(state['steps_tried'])}\n\n"
                "The IT team will follow up within 4 business hours.\n"
                "Type **menu** to start a new session."
            )
        else:
            await turn_context.send_activity(
                "⚠️ Could not send the escalation email (check SMTP settings).\n\n"
                "Please email **it-helpdesk@yourcompany.com** directly and "
                f"quote asset ID `{state['asset_id']}`."
            )

        _reset(state)


# ── Utility ────────────────────────────────────────────────────────────────────

def _reset(state: dict):
    """Reset all fields in the conversation state dict."""
    state["category_key"]      = ""
    state["step_index"]        = 0
    state["steps_tried"]       = []
    state["awaiting_asset_id"] = False
    state["asset_id"]          = ""
